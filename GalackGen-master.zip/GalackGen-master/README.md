<center><img alt="GalackGen" src="https://i.imgur.com/HKodxPv.png"></center>

[![](https://img.shields.io/discord/918257651392061500.svg?logo=discord&colorB=7289DA)](https://discord.gg/EwNjXAyn7Y)
[![](https://img.shields.io/badge/discord.js-v12.0.0--dev-blue.svg?logo=npm)](https://github.com/discordjs)
[![](https://img.shields.io/badge/paypal-donate-blue.svg)](https://paypal.me/GalackQSM?country.x=FR&locale.x=fr_FR)
[![](https://img.shields.io/github/languages/top/GalackQSM/GalackGen?style=flat-square)]()
[![](https://img.shields.io/github/last-commit/GalackQSM/GalackGen?style=flat-square)]()
[![](https://img.shields.io/github/license/GalackQSM/GalackGen?style=flat-square)]()
[![](https://img.shields.io/github/downloads/GalackQSM/GalackGen/total?color=%23daff00&label=Downloads&style=flat-square)]()
[![](https://img.shields.io/github/stars/GalackQSM/GalackGen?color=%23daff00&label=Stars&style=flat-square)]()
[![](https://img.shields.io/github/forks/GalackQSM/GalackGen?color=%23daff00&label=Forks&style=flat-square)]()

GalackGen est un bot Discord de génération de compte open source codé en JavaScript avec [Discord.js](https://discord.js.org) par [GalackQSM](https://github.com/GalackQSM).  
N'hésitez pas à ajouter une étoile ⭐ au référentiel pour promouvoir le projet!

### Bot

Offres GalackGen:
*   ✉️ Vous pouvez crée vos propre compte
*   🇫🇷 Marche que sur un seul salon pour évité le spam
*   ⚙️ Chaque compte généré et directement supprimer

### Commandes

* gen (Nom du service) - Générer des comptes
* create (Nom du service) - Créer un service
* restock (Nom du service) (Nombre de compte) - Notifier les restocks de compte
* add (mail:pass) (Nom du service) - Ajouter des comptes
* stats - Afficher les statistiques de GalackGen

## Installation

* Aller dans le fichier `config.json` et mettez le bot de votre bot
* Toujours dans le fichier `config.json` dans `botChannel`mettez l'id du salon ou seul le bot pourras fonctionner
* Ensuite allez dans CMD et faite `node index.js`

Pour restock des comptes, vous pouvez directement les restocks a partir du fichier sans redémarrer votre bot, dans le dossier `comptes`
## Liens

*   [Discord](https://discord.gg/EwNjXAyn7Y)
*   [Twitter](https://twitter.com/Galack_QSM)
*   [Github](https://github.com/GalackQSM/)

